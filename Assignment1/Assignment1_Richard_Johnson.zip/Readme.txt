Readme.txt

Jupiter notebook was used to create this python notebook.

Dataset used:
Auto MPG
https://archive.ics.uci.edu/ml/datasets/Auto+MPG

Files included:
Assignment 1.ipynb
Auto-mpg.data-originial
Similarity Matrix.csv
Readme.txt